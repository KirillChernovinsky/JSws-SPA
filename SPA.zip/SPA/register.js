// const registrationForm = document.getElementById("registrationForm");
// const message = document.getElementById("message");

// registrationForm.addEventListener("submit", (e) => {
//     e.preventDefault();

//     const username = document.getElementById("username").value;
//     const email = document.getElementById("email").value;
//     const password = document.getElementById("password").value;


//     alert(`${username}, был зарегистрирован`)
// });


// reg
let users = [],
isAuth = false;
document.addEventListener('click', (event) => {
    if (event.target.classList.contains('btn_reg')) {
        let form = document.forms.registration,
            login = form.elements[0].value,
            email = form.elements[1].value,
            pass = form.elements[2].value,
            pass2 = form.elements[3].value;
        event.preventDefault();
        if (pass === pass2 && pass !== '') {
            users.push({login, email, pass})
            isAuth = true;
        } else {
            isAuth = false
        }
    }
})


