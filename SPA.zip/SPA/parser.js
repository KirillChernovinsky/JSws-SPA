// fetch('https://jsonplaceholder.typicode.com/posts')
//   .then(response => response.json())
//   .then(data => {
//     // Обработка полученных данных
//     console.log(data);
//   })
//   .catch(error => {
//     // Обработка ошибки
//     console.error(error);
//   });


// data = fetch('https://jsonplaceholder.typicode.com/posts')
// console.log(data)
for (let key in fetch('https://jsonplaceholder.typicode.com/posts')) {
if (data.hasOwnProperty(key)) {
    console.log(key + ': ' + data[key]);
}
}